# Zielnik osobowości

Gotowa, samodzielna strona quizu w jednym pliku: `index.html`.

## Publikacja przez GitHub Pages (bezpłatnie)

1. Zaloguj się lub utwórz konto na https://github.com
2. Utwórz nowe repozytorium, np. `zielnik-osobowosci`.
3. Ustaw repozytorium jako **Public**.
4. Wybierz **Add file → Upload files** i prześlij `index.html`.
5. Zatwierdź zmiany przyciskiem **Commit changes**.
6. Otwórz **Settings → Pages**.
7. W sekcji **Build and deployment** wybierz:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
8. Kliknij **Save** i poczekaj chwilę na publikację.
9. GitHub pokaże adres strony w sekcji Pages, zwykle:
   `https://TWOJA-NAZWA.github.io/zielnik-osobowosci/`

Po każdej aktualizacji pliku `index.html` i zapisaniu zmian strona zaktualizuje się automatycznie.

## Co zawiera strona
- responsywny quiz w języku polskim;
- cztery możliwe wyniki;
- pasek postępu, wybór odpowiedzi, cofanie i ponowne rozwiązanie;
- udostępnianie wyniku przez funkcję przeglądarki;
- sekcję ciekawostek z linkami do NCCIH (NIH).

Strona nie używa zewnętrznych bibliotek ani nie zbiera odpowiedzi użytkowników.
